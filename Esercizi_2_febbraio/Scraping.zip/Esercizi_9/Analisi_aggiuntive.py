import pandas as pd

df = pd.read_json(r"C:\Users\fedeb\OneDrive\Desktop\Python\9_lezione\Esercizi_9\news_crawler\Wikilink\link_pagina.json")

# Per trovare quanti collegamenti ipertestuali ci sono
link_tot = df["link"].count()
print("In totale, nella pagina, sono presenti", link_tot, "collegamenti ipertestuali")

# Per vedere quante volte vengono ripetuti i vari link
conta_link = df["link"].value_counts()
print(conta_link)

# Per stampare solo il nome del link citato più volte
massimo = df["link"].value_counts().idxmax()
print("Il link citato più volte è:", massimo)

# Tutti i link citati più di una volta
conta_link = conta_link[conta_link > 10]
print(conta_link)

unique_link = df["link"].unique()
#print(unique_link)


'''
Il collegamento ipertestuale più ripetuto fa riferimento ad un libro di:
Francesca Cosi e Alessandra Repossi, 
Guida completa alla saga di Harry Potter: 
I libri, i film, i personaggi, i luoghi, l'autrice, il mito, Antonio Vallardi Editore, 2016, ISBN 978-88-6987-093-4.
'''