import scrapy


class WikiLinksSpider(scrapy.Spider):
    name = "wiki_links"
    start_urls = ["https://it.wikipedia.org/wiki/Harry_Potter"]

    def parse(self, response):
        links = response.css("a::attr(href)").getall()
        for link in links:
            yield {
                "link":link
            }
