import scrapy


class NewtitlesSpider(scrapy.Spider):
    name = "newtitles"
    start_urls = ["https://www.mymovies.it/saga/harry-potter/"]

    def parse(self, response):
        titles = response.css("h1::text").extract()
        for title in titles:
            yield {
                "title":title
            }
