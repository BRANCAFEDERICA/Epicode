import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats


df = pd.read_csv(r"C:\Users\fedeb\OneDrive\Desktop\Python\10_lezione\Normalizzazione_dati\dataset_climatico.csv")

# pulizia del dataset
print(df.isnull().sum())
df.dropna(inplace=True)

# normalizzazione attraverso la libreria scipy
normalizzazione_colonne = ["temperatura_media", "precipitazioni", "umidita", "velocita_vento"]
df[normalizzazione_colonne] = stats.zscore(df[normalizzazione_colonne])

df.to_csv('dati_ripuliti.csv', index=False)

# statistiche descrittive
stat = df.describe()
print(stat)

# converto la colonna del dataset in valori temporali
df['data_osservazione'] = pd.to_datetime(df['data_osservazione'])

# metto come indice la data di osservazione
df.set_index("data_osservazione", inplace=True) 

# costuisco un grafico di tipo box plot per raffigurare la temperatura media
# prima però ridefinisco le osservazioni temporali come mesi 

df.resample("M")["temperatura_media"].mean().plot(kind="box")
plt.title("Temperatura media")
plt.ylabel("Gradi")
plt.savefig("Temperatura_Media.png", dpi=300)
plt.show()

print("La temp media più alta è di:", df['temperatura_media'].max())

print("La temp media più bassa è di:", df['temperatura_media'].min())

# costruiscono anche un istogramma della distribuzione delle temperature

sns.histplot(data=df, x="temperatura_media", kde =True)
plt.ylabel("Frquenza")
plt.title("Distribuzione Temperatura Media")
plt.savefig("Temperatura_Media_hist.png", dpi=300)
plt.show()

# per il resto dei dati costruisco boxplot

plt.figure(figsize=(10,8))
df.resample("M")[["precipitazioni","umidita","velocita_vento"]].mean().plot(kind="box")
plt.ylabel("Valori")
plt.title("Distribuzione Precipitazioni, umidita, velocità vento Medie")
plt.savefig("Precipitazioni_umidita_vento.png", dpi=300)
plt.show()



# costruiscono una heatmap 
# prima definisco su quali variabili fare le correlazioni
corr= df[['temperatura_media', 'precipitazioni', 'umidita', 'velocita_vento']].corr()
print(corr)

# poi definisco la heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(corr, cmap='coolwarm', annot=True)
plt.title('Correlazione tra Variabili Meteorologiche')
plt.savefig("Correlazione.png", dpi=300)
plt.show()

# analisi aggiuntive 
# vedere la temperatura media nelle diverse stazioni metereologiche

plt.figure(figsize=(10,8))
sns.histplot(data=df, x='stazione_meteorologica', weights=df['temperatura_media'])
plt.title('Distribuzione Temperatura media')
plt.xlabel('Stazione Metereologica')
plt.ylabel('Temmperatura media')
plt.savefig("Stazione_meteo.png", dpi=300)
plt.show()
