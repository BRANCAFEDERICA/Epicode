import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

data = pd.read_csv("./analisi_pulite.csv")

# Proseguo ad analizzare i dati 

# 1. Calcolo la percentuale di maschi e femmine presenti all'interno del dataset
percentuale_sesso = (data['sex'].value_counts() / len(data)) * 100

print(f" Percentuale di maschi: {percentuale_sesso['male']:.1f}%")
print(f"Percentuale di femmine: {percentuale_sesso['female']:.1f}%")

'''
Il campione è omogeno per la varibiale genere
'''

# 2. Calcolo la percentuale di fumatori e non fumatori
percentuale_fumatori = (data['smoker'].value_counts() / len(data)) * 100

print(f"Percentuale di fumatori: {percentuale_fumatori['yes']:.1f}%")
print(f"Percentuale di non fumatori: {percentuale_fumatori['no']:.1f}%")

'''
La percentuale dei fumatori è minore rispetto ai non fumatori.

'''

# 3. Mi creo un grafico per visualizzare la distribuzione dell'età
conteggio_per_eta = data['age'].value_counts().sort_index()


plt.figure(figsize=(12, 6))
sns.barplot(x=conteggio_per_eta.index, y=conteggio_per_eta.values,color='blue')
plt.title("Distribuzione delle età")
plt.xlabel("Età")
plt.ylabel("Conteggio")
plt.savefig("Distribuzione_età.png")
plt.show()

'''
La distribuzione dell'età del campione è omogenea, 
seppur sono presente molte persone di 18 e 19 anni.

'''

