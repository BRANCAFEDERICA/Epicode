import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

data = pd.read_csv("./analisi_pulite.csv")

# Grafico a torta per il numero dei figli

numero_figli = data['children'].value_counts()

plt.pie(numero_figli, labels=numero_figli.index, autopct='%1.1f%%',startangle=90)
plt.axis('equal')
plt.title('Distribuzione del numero di figli nel dataset')
plt.savefig("Distribuzione_figli.png")
plt.show()

'''
La maggior parte degli individui (42,9%) non hanno figli a carico,
mentre il 24% della popolazione ha solo un figlio a carico

'''

