import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

# Carico il dataset 
data = pd.read_csv("./insurance.csv")

# Inizio con effettuare una pulizia del dataset

# 1. Controllo se sono presenti valori NaN
null_value = data.isna().sum()
print(null_value)

# 2. Rimuovo le righe con valori mancanti
data = data.dropna()

# 3. Sostituisco i valori mancanti con un valore specifico
data = data.fillna(0)

# 4. Rimuovo i duplicati
data = data.drop_duplicates()

# Salvo il dataset ripulito, su cui poi effettuerò le analisi
data.to_csv('analisi_pulite.csv', index=False)

# Passo poi a visualizzare le prime informazioni relative al dataset
data.info()

# Inizio a fare un'analisi esplorativa con la funzione describe
describe_df = data.describe()

# Visualizzo anche i dati relative delle variabili qualitative
print(data.describe(include = "object"))

# Imposto uno stile al dataframe per migliorarne la visualizzazione
sns.set(style="whitegrid")
plt.figure(figsize=(12, 6))


# Creo una heatmap con il risultato di describe
sns.heatmap(describe_df, annot=True, fmt=".2f", cmap='coolwarm', linewidths=.5, cbar=False)
plt.title("Descrizione del Dataset")

# Salvo il grafico
plt.savefig("Descrizione_dataset.png")
plt.show()
