import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns 

data = pd.read_csv("./analisi_pulite.csv")

# Analisi del cossto sanitario nelle diverse aree geografiche
plt.figure(figsize=(12, 8))
sns.boxplot(x='region', y='charges', data=data, palette='viridis')
plt.title('Differenze di costo tra regioni')
plt.xlabel('Regione')
plt.ylabel('Spese mediche')
plt.savefig("Costi_per_regioni.png")
plt.show()

'''
Non sono emerse particolari differenze tra le diversi regioni, ma
nella regione di “Southeast” il range delle spese sostenute è maggiore rispetto che nelle altre ragioni

'''