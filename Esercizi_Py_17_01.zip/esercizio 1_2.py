#1 esercizio Stampare ogni carattere della stringa, uno su ogni riga, utilizzando un costrutto while.
nome_scuola = "Epicode"
lunghezza = len(nome_scuola)
carattere = 0
while carattere < lunghezza:
    print(nome_scuola[carattere])
    carattere += 1

#2 esercizio Stampare a video tutti i numeri da 0 a 20 utilizzando il costrutto while.
n = 0
while n <= 20:
    print (n)
    n += 1
