#3 esercizio Calcolare e stampare tutte le prime 10 potenze di 2 (e.g., 2⁰, 2¹, 2², …) utilizzando un ciclo while
n = 2
potenza = 0
while potenza <= 10:
    print (n ** potenza) 
    potenza += 1

#4 esercizio Calcolare e stampare tutte le prime N potenze di 2 utilizzando un ciclo while, domandando all'utente di inserire N.
N = int(input ('inserisci un numero da 1 a 10: '))
numero = 2
potenza = 0
while potenza <= N:
    print (n ** potenza)
    potenza += 1

#5 esercizio Calcolare e stampare tutte le potenze di 2 minori di 25000.
n = 2
potenza = 0
while n**potenza <= 25000:
    print (n**potenza) 
    potenza += 1